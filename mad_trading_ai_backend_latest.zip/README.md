# MaD Trading AI - Backend

Backend per MaD Trading AI, creato con FastAPI.

## Come funziona

POST `/analyze` accetta uno screenshot di un grafico e restituisce:
- LONG o SHORT
- Entry, SL, TP
- Percentuale di successo
- Motivazioni tecniche

## Deploy su Render

- **Build Command:**
  pip install -r requirements.txt

- **Start Command:**
  uvicorn main:app --host=0.0.0.0 --port=10000