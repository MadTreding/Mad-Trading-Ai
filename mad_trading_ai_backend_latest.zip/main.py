from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    return {
        "signal": "LONG",
        "success_rate": 82,
        "entry": 178.10,
        "stop_loss": 175.90,
        "take_profit": 181.60,
        "reasons": ["Structure CHoCH", "BOS confirmed", "Premium zone rejected", "Momentum bullish"]
    }